from django.contrib import admin
from .models import Blog, Blogdealer, Blogquestion

admin.site.register(Blog)
admin.site.register(Blogquestion)
admin.site.register(Blogdealer)

# Register your models here.
